export class sendMailDto {
    email: string;
    numberOfTickets: number;
}