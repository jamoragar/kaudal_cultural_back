import { Controller } from '@nestjs/common';

@Controller('event')
export class EventController {}
