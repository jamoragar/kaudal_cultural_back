export class createClientDto {
    names: string;
    lastNames: string;
    email: string;
    cellphone?: string
    numberOfTickets: number;
}